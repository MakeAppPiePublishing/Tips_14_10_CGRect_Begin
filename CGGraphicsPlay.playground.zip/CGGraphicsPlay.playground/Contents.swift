import UIKit

class ViewController:UIViewController{
    var imageView1 = UIImageView()
    var imageView2 = UIImageView()
    
    func drawStuff(){
        
    }
    
    override func viewDidLoad(){
        super.viewDidLoad()
        imageView1.frame = CGRect(x: 0, y: 0, width: 50, height: 50)
        imageView1.backgroundColor = .blue
        view.addSubview(imageView1)
        imageView2.frame = CGRect(x: 0, y: 20, width: 50, height: 50)
        imageView2.backgroundColor = .green
        view.addSubview(imageView2)
        drawStuff()
    }
    
    override func loadView(){
        let view = UIView()
        view.frame = CGRect(x: 0, y: 0, width: 150, height: 150)
        view.backgroundColor = .systemBackground
        self.view = view
    }
}

import PlaygroundSupport
let vc = ViewController()
PlaygroundPage.current.setLiveView(vc)
